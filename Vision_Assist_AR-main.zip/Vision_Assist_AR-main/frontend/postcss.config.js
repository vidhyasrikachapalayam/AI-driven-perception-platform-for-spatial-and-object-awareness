export const plugins = {
  '@tailwindcss/postcss': {},
  autoprefixer: {},
};
